=== Bettenbörse ===
Contributors: Lukas Mateffy
Tags: wordpress, asta, bettenboerse
Requires at least: 5.9
Tested up to: 5.9
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Funktionen für die AStA Bettenbörse.

== Description ==

Funktionen für die AStA Bettenbörse.

== Installation ==

Installation

== Screenshots ==

1. Das Haupt-Interface

== Frequently Asked Questions ==

= What is the plugin template for? =

This plugin template is designed to help you get started with any new WordPress plugin.

== Changelog ==

= 1.0.1 =
* 2022-04-14
* GitHub updating added


= 1.0.0 =
* 2022-04-01
* Initial release

== Upgrade Notice ==

= 1.0.0 =
* 2022-04-01
* Initial release
